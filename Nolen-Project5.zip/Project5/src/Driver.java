/**
 * Starts the Gorillas game
 * @author Drew Nolen
 * @version 4/25/2016
 *
 */
public class Driver {
	
	/**
	 * Starts the Gorillas game
	 * @param args command line arguments
	 */
	public static void main(String[] args)
	{
		new GameFrame();
	}

}
